//
//  AddRecipeViewController.h
//  Cooking Buddy Navigation
//
//  Created by Christine Ho on 5/8/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RecipeStorage.h"

@interface AddRecipeViewController : UIViewController <UITextFieldDelegate, UITextViewDelegate>

@property (strong, nonatomic) NSMutableArray *m;
@property (nonatomic, retain) AddRecipeViewController *delegate;

@property (strong, nonatomic) IBOutlet UITextField *recipeName;
@property (strong, nonatomic) IBOutlet UITextField *servingSize;
@property (strong, nonatomic) IBOutlet UITextView *ingredients;
@property (strong, nonatomic) NSMutableDictionary *ingredientList;
@end

