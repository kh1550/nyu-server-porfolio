//
//  AddRecipeViewController.m
//  Cooking Buddy Navigation
//
//  Created by Christine Ho on 5/8/15.
//  Added Ingredients add features Michelle Chen 5/11/15
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import "AddRecipeViewController.h"
#import "AddStepViewController.h"
#import "RecipeStorage.h"
#import "AppDelegate.h"

@interface AddRecipeViewController ()
@property (weak, nonatomic) IBOutlet UITextField *ingredientName;
@property (weak, nonatomic) IBOutlet UITextField *ingredientSize;
@property (weak, nonatomic) IBOutlet UIButton *addIngredientButton;
@property (weak, nonatomic) IBOutlet UISwitch *faveSwitch;
@end

NSMutableArray* ingredientList;

@implementation AddRecipeViewController

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.ingredientList count];
}

//- (void)viewWillAppear:(BOOL)animated {
//    [self.tableView reloadData];
//}
- (IBAction)addIngredientButtonPressed:(id)sender {
    NSArray *ingredientNameAndSize = @[self.ingredientName.text, self.ingredientSize.text];
    [ingredientList addObject: ingredientNameAndSize];
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    //Updates the ingredient list and quantity. Each index of ingredientList holds an array
    //of size 2 which has the ingredient name (as NSString) in index 0 and quantity (also
    //as NSString in index 1.
    [delegate.recipe setIngredients:ingredientList];
    
    self.ingredientName.text = @"";
    self.ingredientSize.text = @"";
    //add these strings to ingredient list data structure. The table view will load from this structure. The table view is for looks and also we should implement removal. Not sure how to go about this atm. 
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.recipeName.delegate = self;
    self.ingredients.delegate = self;
    self.servingSize.delegate = self;
    ingredientList = [NSMutableArray new];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)savePressed:(id)sender {
    // Save the data to App Delegate
    RecipeStorage *finalRecipe = [RecipeStorage new];
    [finalRecipe setName: self.recipeName.text];
    [finalRecipe setServingSize: self.servingSize.text];
    if (_faveSwitch.on) {
        [finalRecipe setFavorite:TRUE];
    } else {
        [finalRecipe setFavorite:FALSE];
    }
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    delegate.recipe= finalRecipe;
    
    // Close view
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    AddStepViewController *addVC = segue.destinationViewController;
    addVC.delegate = self;
}
- (IBAction)addStepMain:(id)sender {
    RecipeStorage *finalRecipe = [RecipeStorage new];
    [finalRecipe setName: self.recipeName.text];
    [finalRecipe setServingSize: self.servingSize.text];
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    delegate.recipe= finalRecipe;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}

@end

