//
//  AddRecipeViewController.h
//  Cooking Buddy Navigation
//
//  Created by Christine Ho on 5/8/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddRecipeViewController.h"

@interface AddStepViewController : UIViewController <UITextFieldDelegate, UITextViewDelegate>
{
}

@property (strong, nonatomic) IBOutlet UITextField *timerMin;
@property (strong, nonatomic) IBOutlet UITextView *instructions;
@property (weak, nonatomic) IBOutlet UITextField *timerSec;

@property (nonatomic, retain) AddRecipeViewController *delegate;

@end


