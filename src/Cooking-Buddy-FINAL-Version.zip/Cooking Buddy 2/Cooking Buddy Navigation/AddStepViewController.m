//
//  AddStepViewController.m
//  Cooking Buddy Navigation
//
//  Created by Christine Ho on 5/8/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import "AddStepViewController.h"
#import "RecipeStorage.h"
#import "AppDelegate.h"

@interface AddStepViewController ()
@property (weak, nonatomic) IBOutlet UILabel *stepName;
@end

@implementation AddStepViewController
NSString *timeInSeconds;
bool initial;
int stepCount = 1;

- (void)viewDidLoad {
    [super viewDidLoad];
    self.instructions.delegate = self;
    self.timerMin.delegate = self;
    self.timerSec.delegate = self;
    initial = ![self readBool:@"initial"];
    self.stepName.text = [NSString stringWithFormat:@"Step %d", stepCount];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) timerConvert{
    int minutes = [self.timerMin.text intValue];
    int seconds = [self.timerSec.text intValue];
    
    minutes = minutes * 60;
    int total = minutes + seconds;
    
    timeInSeconds = [NSString stringWithFormat:@"%d", total];
}

- (IBAction)finishPressed:(id)sender {
    // Save all the data
    RecipeStorage *step = [RecipeStorage new];
    [step setInstruction: self.instructions.text];
    [self timerConvert];
    [step setTimer: timeInSeconds];
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.steps addObject:step];
    
    RecipeStorage *finalRecipe = [RecipeStorage new];
    
    finalRecipe = delegate.recipe;
    for(int i = 0; i < [delegate.steps count]; i++)
    {
        RecipeStorage *stepData = [RecipeStorage new];
        stepData = [delegate.steps objectAtIndex:i];
        [finalRecipe addInstruction:[stepData instruction] addTimer:[stepData timer]];
    }
    
    NSMutableDictionary *dict = [NSMutableDictionary new];
    
    [finalRecipe setName: [delegate.recipe name]];
    [finalRecipe setIngredients: [delegate.recipe ingredients]];
    [finalRecipe setServingSize:[delegate.recipe servingSize]];
    [dict setObject: finalRecipe forKey: [finalRecipe name]];
    [finalRecipe print];
    [finalRecipe printArray];
    
    //Checks if there already exists custom recipes
    if(initial == true){
        [dict setObject: finalRecipe forKey: [finalRecipe name]];
        [self writeArrayWithCustomObjToUserDefaults:@"allRecipes" withArray:dict];
        [self writeBool:@"initial" withBool:true];
        
    }
    else{
        dict = [self readArrayWithCustomObjFromUserDefaults:@"allRecipes"];
        [dict setObject: finalRecipe forKey: [finalRecipe name]];
        [self writeArrayWithCustomObjToUserDefaults:@"allRecipes" withArray: dict];
    }
    
    NSLog(@"Dictionary: %@", [self readArrayWithCustomObjFromUserDefaults:@"allRecipes"]);
    
    
    // Print to NSLog so we can see
    //[finalRecipe print];
    //[finalRecipe printArray];
    
    // Get back to home page without using navigation back
    NSArray *array = [self.navigationController viewControllers];
    [self.navigationController popToViewController:[array objectAtIndex:1] animated:YES];
    
}

- (IBAction)addStepPressed:(id)sender {
    // Save the data
    RecipeStorage *step = [RecipeStorage new];
    [step setInstruction: self.instructions.text];
    [self timerConvert];
    [step setTimer: timeInSeconds];
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.steps addObject:step];
    
    
    // Reset fields
    timeInSeconds = 0;
    stepCount++;
    self.timerMin.text = @"0";
    self.timerSec.text = @"0";
    self.instructions.text = @"Write instructions here.";
    self.stepName.text = [NSString stringWithFormat:@"Step %d", stepCount];
}

//saves RecipeStorage object to NSUserDefaults after encoding it properly.
-(void)writeArrayWithCustomObjToUserDefaults:(NSString *)keyName withArray:(NSMutableDictionary *)myArray {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:myArray];
    [defaults setObject:data forKey:keyName];
    [defaults synchronize];
}

//reads RecipeStorage object properly from NSUserDefaults.
-(NSMutableDictionary *)readArrayWithCustomObjFromUserDefaults:(NSString*)keyName {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSData *data = [defaults objectForKey:keyName];
    NSMutableDictionary *myArray = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    return myArray;
}

//saves bool to NSUserDefaults properly.
-(void)writeBool:(NSString *)keyName withBool:(BOOL )myBool {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setBool:myBool forKey:keyName];
    [defaults synchronize];
}

//reads bool from NSUserDefaults properly.
-(BOOL)readBool:(NSString*)keyName {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    BOOL myBool = [defaults boolForKey:keyName];
    return myBool;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}


@end

