//
//  AppDelegate.h
//  Cooking Buddy Navigation
//
//  Created by Michelle Chen on 4/30/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RecipeStorage.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) RecipeStorage* recipe;
@property (strong, nonatomic) NSMutableArray* steps;
//@property (strong, nonatomic) NSMutableArray* miscInfo;
@end

