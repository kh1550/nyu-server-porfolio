//
//  CustomRecipes.m
//  Cooking Buddy Navigation
//
//  Created by Michelle Chen on 4/30/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import "CustomRecipes.h"

@interface CustomRecipes ()
@property (strong, nonatomic) NSMutableArray *favorites;
@end

@implementation CustomRecipes{
    
}


+ (instancetype)sharedFavoritesList {
    static CustomRecipes *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shared = [[self alloc] init];
    });
    return shared;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        NSArray *storedFavorites = [defaults objectForKey:@"favorites"];
        if (storedFavorites) {
            self.favorites = [storedFavorites mutableCopy];
        } else {
            self.favorites = [NSMutableArray array];
        }
    }
    return self;
}

- (void)addFavorite:(id)item {
    [_favorites insertObject:item atIndex:0];
    [self saveFavorites];
}
- (void)removeFavorite:(id)item {
    [_favorites removeObject:item];
    [self saveFavorites];
}
- (void)saveFavorites {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:self.favorites forKey:@"favorites"];
    [defaults synchronize];
}



@end