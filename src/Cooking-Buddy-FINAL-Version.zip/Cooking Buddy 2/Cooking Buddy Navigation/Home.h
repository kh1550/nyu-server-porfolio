//
//  Home.h
//  Cooking Buddy Navigation
//
//  Created by Michelle Chen on 5/3/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Home : UIViewController

@end
