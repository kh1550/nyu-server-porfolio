//
//  IngredientsViewController.h
//  Cooking Buddy Navigation
//
//  Created by Christine Ho on 5/9/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RecipeStorage.h"

@interface IngredientsViewController : UIViewController
@property (strong, nonatomic) RecipeStorage *recipe;
@property (weak, nonatomic) IBOutlet UIImage *food1;
@end
