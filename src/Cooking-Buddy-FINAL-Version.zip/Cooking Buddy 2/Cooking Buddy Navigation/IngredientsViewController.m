//
//  IngredientsViewController.m
//  Cooking Buddy Navigation
//
//  Created by Christine Ho on 5/9/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import "IngredientsViewController.h"

@interface IngredientsViewController (){
    int serving;
}
@property (weak, nonatomic) IBOutlet UILabel *ingredients;
@property (weak, nonatomic) IBOutlet UILabel *servingsizetext;
@property (weak, nonatomic) IBOutlet UISlider *servingslider;

@end

@implementation IngredientsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.ingredients.text = [self.recipe ingredients];
    self.servingsizetext.text = @"Serving Size:1";
    self.servingslider.continuous = YES;
    self.servingslider.minimumValue = 0;
    self.servingslider.maximumValue = 10;
    
}

- (IBAction)changedValue:(id)sender {
    self.servingsizetext.text = [NSString stringWithFormat:@"Serving Size: %i",(int)self.servingslider.value];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
