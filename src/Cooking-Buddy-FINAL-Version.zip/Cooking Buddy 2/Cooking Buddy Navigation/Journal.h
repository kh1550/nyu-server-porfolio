//
//  Journal.h
//  Cooking Buddy Navigation
//
//  Created by Michelle Chen on 4/30/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Journal : UITableViewController
@property (copy, nonatomic) NSArray *journalNames;
@property (copy, nonatomic) NSArray *myRecipes;
@property (copy, nonatomic) NSArray *completedRecipes;
@property (copy, nonatomic) NSArray *favoriteRecipes;
@property (strong, nonatomic) NSMutableDictionary *allRecipes;

@end
