//
//  Journal.m
//  Cooking Buddy Navigation
//
//  Created by Michelle Chen on 4/30/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import "Journal.h"
#import "RecipeHome.h"
#import "RecipeStorage.h"


@interface Journal ()

@end

@implementation Journal
    //NSArray* fontNames;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.journalNames = [NSArray arrayWithObjects: @"My Recipes", @"Completed Recipes" , @"Favorite Recipes", nil];
    self.myRecipes = [NSArray arrayWithArray:[self.allRecipes allKeys]];
    self.completedRecipes = [NSArray arrayWithObjects:@"Mushroom Risotto", @"Three-cup Chicken",nil];
    self.favoriteRecipes = [NSArray arrayWithObjects:@"Salmon Avocado Sushi", @"Meatloaf", @"Spaghetti & Meatballs", nil];
}

- (void)viewWillAppear:(BOOL)animated {
    [self.tableView reloadData];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [self.journalNames count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if(section == 0){
        return [self.myRecipes count];
    }
    else if(section == 1){
        return [self.completedRecipes count];
    }
    else if(section == 2){
        return [self.favoriteRecipes count];
    }
    else{
        return 0;
    }
    
}

- (NSString *)tableView:(UITableView *)tableView
titleForHeaderInSection:(NSInteger)section {
    if(section == 0) {
        return [self.journalNames objectAtIndex:(0)];
    }
    else if(section == 1){
        return [self.journalNames objectAtIndex:(1)];

    }
    else if(section == 2){
        return [self.journalNames objectAtIndex:(2)];
        
    }else{
        return @"";
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *myRecipeCell = @"myRecipeCell";
    static NSString *completedRecipeCell = @"completedRecipeCell";
    static NSString *favoriteRecipeCell = @"favoriteRecipeCell";
    
    UITableViewCell *cell = nil;
    if(indexPath.section == 0){
        cell = [tableView dequeueReusableCellWithIdentifier:myRecipeCell forIndexPath:indexPath];
        cell.textLabel.text = self.myRecipes[indexPath.row];
        //[cell.imageView setImage:[UIImage imageNamed:@"Main0.png"]];
    }
    else if(indexPath.section == 1){
        cell = [tableView dequeueReusableCellWithIdentifier:completedRecipeCell forIndexPath:indexPath];
        cell.textLabel.text = self.completedRecipes[indexPath.row];
    }
    else if(indexPath.section == 2){
        cell = [tableView dequeueReusableCellWithIdentifier:favoriteRecipeCell forIndexPath:indexPath];
        cell.textLabel.text = self.favoriteRecipes[indexPath.row];
    }
    
    // Change cell font
    cell.textLabel.font = [UIFont fontWithName:@"Marker Felt" size:18];

    return cell;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController]. // Pass the selected object to the new view controller.
    NSIndexPath *indexPath = [self.tableView indexPathForCell:sender];
    RecipeHome *listVC = segue.destinationViewController;
    
    if(indexPath.section == 0) {
        NSString *pageName = self.myRecipes[indexPath.row];
        listVC.navigationItem.title = pageName;
        listVC.allRecipes = [[NSMutableDictionary alloc] init];
        [listVC.allRecipes addEntriesFromDictionary:self.allRecipes];
        // Change the name of the back button
        listVC.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:nil action:nil];
        if(indexPath.row == 0){
            listVC.food = [UIImage imageNamed:@"steak.jpg"];
        }
        if(indexPath.row == 1){
            listVC.food = [UIImage imageNamed:@"garlicchicken.jpg"];
        }
    }
}


@end
