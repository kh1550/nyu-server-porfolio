//
//  NavigationPages.h
//  Cooking Buddy Navigation
//
//  Created by Michelle Chen on 4/30/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RecipeStorage.h"

@interface NavigationPages : UITableViewController
@property (strong, nonatomic) NSMutableDictionary *allRecipes;
@property (strong, nonatomic) RecipeStorage *addRecipe;
@property (strong, nonatomic) NSString *addName;
@end
