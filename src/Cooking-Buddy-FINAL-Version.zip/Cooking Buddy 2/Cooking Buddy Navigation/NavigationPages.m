//
//  NavigationPages.m
//  Cooking Buddy Navigation
//
//  Created by Michelle Chen on 4/30/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import "NavigationPages.h"
#import "RecipeStorage.h"
#import "AppDelegate.h"
#import "Journal.h"

@interface NavigationPages ()

@property (copy, nonatomic) NSArray *pageNames;
@end

@implementation NavigationPages

- (void)viewDidLoad {
    [super viewDidLoad];
    // Set up notification for when this view becomes active
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(becomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
    
    // Bring back navigation bar
    [self.navigationController setNavigationBarHidden:NO];
    
    // Alloc dictionary
    self.allRecipes = [[NSMutableDictionary alloc] init];
    // Hardcoded recipes
    RecipeStorage *gc = [RecipeStorage new];
    [gc setIngredients:@"\nCrushed garlic\t\thalf a cup\nOnion\t\t\t\thalf\nFish sauce\t\t\t2 tsp\nChicken breast\t4\nOlive Oil\t\t\t1 tbsp\nBrown Sugar\t\t4 tbsp\n"];
    
    [gc addInstruction:@"Preheat oven to 375 degrees F (190 C)" addTimer:@"0"];
    [gc addInstruction:@"In a small saucepan melt butter/margarine with garlic. Dip chicken pieces in butter/garlic sauce, letting extra drip off, then coat completely with bread crumbs." addTimer:@"0"];
    [gc addInstruction:@"Place coated chicken in a lightly greased 9x13 inch baking dish. Combine any leftover butter/garlic sauce with bread crumbs and spoon mixture over chicken pieces. Bake in oven for 45 minutes." addTimer:@"2700"];
    [self.allRecipes setObject:gc forKey:@"Garlic Chicken"];
    RecipeStorage *new = [RecipeStorage new];
    [new addInstruction:@"Cook one side for two minutes" addTimer:@"120"];
    [new addInstruction:@"Flip the steak and cook the other side for two minutes" addTimer:@"120"];
    [new addInstruction:@"Add sliced butter on top of the steak" addTimer:@"0"];
    [self.allRecipes setObject:new forKey:@"Grilled Steak"];
}

- (void)becomeActive:(NSNotification *)notification {
    [self viewDidAppear:YES];
}

- (void)viewDidAppear:(BOOL)animated {
    // If you would like to see that a recipe is succesfully added
    NSArray *keys = [self.allRecipes allKeys];
    NSLog(@"%d", (int)[keys count]);
    
    // Set up array for table view
    self.pageNames = [NSArray arrayWithObjects:@"Home", @"Journal", @"Search", @"Add Recipe", @"Settings", nil];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 5;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (void)viewWillAppear:(BOOL)animated {
    [self.tableView reloadData];
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *HomeCell = @"HomeCell";
    static NSString *JournalCell = @"JournalCell";
    static NSString *SearchCell = @"SearchCell";
    static NSString *AddRecipeCell = @"AddRecipeCell";
    static NSString *SettingsCell = @"SettingsCell";

    
    UITableViewCell *cell = nil;
    
    if(indexPath.section == 0){
        cell = [tableView dequeueReusableCellWithIdentifier:HomeCell forIndexPath:indexPath];
        cell.textLabel.text = @"Home";
    }
    else if(indexPath.section == 1){
        cell = [tableView dequeueReusableCellWithIdentifier:JournalCell forIndexPath:indexPath];
        cell.textLabel.text = @"Journal";
    }
    else if(indexPath.section == 2){
        cell = [tableView dequeueReusableCellWithIdentifier:SearchCell forIndexPath:indexPath];
        cell.textLabel.text = @"Search";
    }
    else if(indexPath.section == 3){
        cell = [tableView dequeueReusableCellWithIdentifier:AddRecipeCell forIndexPath:indexPath];
        cell.textLabel.text = @"Add Recipe";
        
    }else if(indexPath.section == 4){
        cell = [tableView dequeueReusableCellWithIdentifier:SettingsCell forIndexPath:indexPath];
        cell.textLabel.text = @"Settings";
    }
    
    // Change font
    cell.textLabel.font = [UIFont fontWithName:@"Marker Felt" size:18];
    
    return cell;
}

#pragma mark - Navigation
// In a story board-based application, you will often want to do a little
// preparation before navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController]. // Pass the selected object to the new view controller.
    NSIndexPath *indexPath = [self.tableView indexPathForCell:sender]; Journal *listVC = segue.destinationViewController;
    
    if(indexPath.section == 0){
        NSString *pageName = self.pageNames[0];
        listVC.navigationItem.title = pageName;
    }
    else if(indexPath.section == 1){
        NSString *pageName = self.pageNames[1];
        listVC.navigationItem.title = pageName;
        listVC.allRecipes = [[NSMutableDictionary alloc] init];
        [listVC.allRecipes addEntriesFromDictionary:self.allRecipes];
    }else if(indexPath.section == 2){
        NSString *pageName = self.pageNames[2];
        listVC.navigationItem.title = pageName;
    }else if(indexPath.section == 3){
        NSString *pageName = self.pageNames[3];
        listVC.navigationItem.title = pageName;
    }else if(indexPath.section == 4){
    NSString *pageName = self.pageNames[4];
    listVC.navigationItem.title = pageName;
}


}

@end
