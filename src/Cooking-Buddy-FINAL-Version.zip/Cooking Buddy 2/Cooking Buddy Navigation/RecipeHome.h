//
//  RecipeHome.h
//  Cooking Buddy Navigation
//
//  Created by Michelle Chen on 4/30/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecipeHome : UIViewController
@property (strong, nonatomic) NSMutableDictionary *allRecipes;
@property (strong, nonatomic) NSString *recipeName;
@property (weak, nonatomic) IBOutlet UIImage *food;
//@property (weak, nonatomic)IBOutlet UIImage *food;

@end
