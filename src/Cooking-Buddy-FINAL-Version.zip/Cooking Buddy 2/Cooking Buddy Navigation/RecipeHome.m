//
//  RecipeHome.m
//  Cooking Buddy Navigation
//
//  Created by Michelle Chen on 4/30/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import "RecipeHome.h"
#import "StepViewController.h"
#import "IngredientsViewController.h"
#import "RecipeStorage.h"

@interface RecipeHome ()
@property (weak, nonatomic) IBOutlet UIImageView *picture;
@end

@implementation RecipeHome

- (void)viewDidLoad {
    [super viewDidLoad];
    // Navigation name changes by iteslf in prepareForSegue
    
    // RECEIVE RECIPE IMAGE
    //UIImage *food = [UIImage imageNamed:@"steak.jpg"];
    [self.picture setImage:self.food];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"toIngredients"]) {
        IngredientsViewController *ingredVC = segue.destinationViewController;
        ingredVC.navigationItem.title = @"Ingredients";
        ingredVC.recipe = [RecipeStorage new];
        ingredVC.recipe = [self.allRecipes objectForKey:self.navigationItem.title];
        ingredVC.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:nil action:nil];
    } else {
        StepViewController *stepVC = segue.destinationViewController;
        stepVC.navigationItem.title = self.navigationItem.title;
        stepVC.recipe = [RecipeStorage new];
        stepVC.recipe = [self.allRecipes objectForKey:self.navigationItem.title];
        stepVC.food1 = self.food;
        stepVC.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:nil action:nil];
    }
}


@end
