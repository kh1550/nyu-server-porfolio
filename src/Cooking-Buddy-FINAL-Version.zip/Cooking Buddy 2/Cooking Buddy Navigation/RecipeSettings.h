//
//  RecipeSettings.h
//  Cooking Buddy Navigation
//
//  Created by Michelle Chen on 5/3/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecipeSettings : UIViewController
@property (strong, nonatomic) NSMutableArray *recipe;
@property (weak, nonatomic) IBOutlet UIImage *food1;

@end
