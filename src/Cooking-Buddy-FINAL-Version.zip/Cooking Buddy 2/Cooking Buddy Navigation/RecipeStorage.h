//
//  RecipeStorage.h
//  Cooking Buddy Navigation
//
//  Created by Christine Ho on 5/10/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RecipeStorage : NSObject {
    NSMutableArray* recipeData;
    NSString* recipeName;
    NSString* instruction;
    NSMutableArray* ingredients;
    NSString* timer;
    NSString* servingSize;
    NSString* servingSizeCounter;
    BOOL favorite;
}

//setters
-(void) setName: (NSString*) a;
-(void) setInstruction: (NSString*) b;
-(void) setIngredients: (NSMutableArray*) c;
-(void) setServingSize: (NSString*) d;
-(void) setTimer: (NSString*) e;
-(void) setFavorite: (BOOL) f;
-(void) setServingSizeCounter: (NSString*) g;

//getters
-(NSString*) name;
-(NSString*) instruction;
-(NSMutableArray*) ingredients;
-(NSString*) timer;
-(NSString*) servingSize;
-(NSString*) servingSizeCounter;
-(BOOL) favorite;

//additional methods
-(void) clearArray;
-(NSMutableArray*) returnArray;
-(void) print;
-(bool) addInstruction: (NSString*) newInstruction addTimer: (NSString*) newTimer;
-(void) printArray;
@end
