//
//  RecipeStorage.m
//  Cooking Buddy Navigation
//
//  Created by Kevin Kong on 5/10/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import "RecipeStorage.h"

@implementation RecipeStorage
RecipeStorage* entry;

-(void) clearArray {
    recipeData = [NSMutableArray new];
}

-(void) setInstruction:(NSString*)b
{
    instruction = b;
}

-(void) setName:(NSString *)a
{
    recipeName = a;
}

-(void) setIngredients:(NSMutableArray *)c
{
    ingredients = c;
}

-(void) setServingSize:(NSString *)d
{
    servingSize = d;
}

-(void) setTimer:(NSString*)e
{
    timer = e;
}

-(void) setFavorite:(BOOL)f {
    favorite = f;
}

-(void) setServingSizeCounter:(NSString *)g
{
    servingSizeCounter = g;
}

-(NSString*) instruction
{
    return instruction;
}

-(NSString*) name
{
    return recipeName;
}

-(NSMutableArray*) ingredients
{
    return ingredients;
}

-(NSString*) timer
{
    return timer;
}

-(NSString*) servingSize
{
    return servingSize;
}

-(NSString*) servingSizeCounter
{
    return servingSizeCounter;
}

-(BOOL) favorite {
    return favorite;
}

-(void) print
{
    NSLog(@"Recipe name:%@ Ingredients:%@ Serving size:%@ Instruction:%@", recipeName, ingredients, servingSize, instruction);
    
}

-(bool) addInstruction:(NSString *)newInstruction addTimer:(NSString *)newTimer
{
    entry = [RecipeStorage new];
    [entry setInstruction: newInstruction];
    [entry setTimer: newTimer];
    
    if([recipeData count] == 0)
    {
        recipeData = [NSMutableArray new];
    }
    [recipeData addObject: entry];
    return true;
}

-(NSMutableArray*) returnArray
{
    return recipeData;
}

-(void) printArray
{
    for(int i = 0; i < [recipeData count]; i++){
        NSLog(@"Contents of array: %@ and timer: %@", [[recipeData objectAtIndex:i] instruction], [[recipeData objectAtIndex:i] timer]);
    }
}

//Encodes custom object properly for storage into NSUserDefaults.
-(void)encodeWithCoder:(NSCoder*) coder{
    [coder encodeObject: recipeName forKey:@"recipeName"];
    [coder encodeObject: ingredients forKey:@"ingredients"];
    [coder encodeObject: instruction forKey:@"instruction"];
    [coder encodeObject: timer forKey:@"timer"];
    [coder encodeObject: servingSize forKey:@"servingSize" ];
    [coder encodeBool:favorite forKey:@"favorite"];
    [coder encodeObject: servingSizeCounter forKey:@"servingSizeCounter"];
}

//Decodes custom object properly when retrieving information from NSUserDefaults.
-(id) initWithCoder:(NSCoder*)coder{
    self = [super init];
    if(self){
        recipeName = [coder decodeObjectForKey:@"recipeName"];
        ingredients = [coder decodeObjectForKey:@"ingredients"];
        instruction = [coder decodeObjectForKey:@"instruction"];
        timer = [coder decodeObjectForKey:@"timer"];
        servingSize = [coder decodeObjectForKey:@"servingSize"];
        favorite = [coder decodeBoolForKey:@"favorite"];
        servingSizeCounter = [coder decodeObjectForKey:@"servingSizeCounter"];
    }
    return self;
}
@end