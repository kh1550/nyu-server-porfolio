//
//  StepListViewController.m
//  Cooking Buddy Navigation
//
//  Created by Christine Ho on 5/3/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import "StepListViewController.h"
#import "RecipeStorage.h"

@interface StepListViewController ()
@property (weak, nonatomic) IBOutlet UINavigationItem *recipeNavigation;
@property (weak, nonatomic) IBOutlet UILabel *instructions;

@end

@implementation StepListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *steps = @"";
    for (int i = 0; i < (int)[[self.recipe returnArray] count]; i++) {
        steps = [NSString stringWithFormat:@"%@ \r %d. %@\n", steps, i+1, [[[self.recipe returnArray] objectAtIndex:i] instruction]];
    }
    self.instructions.text = steps;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
