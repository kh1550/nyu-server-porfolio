//
//  StepViewController.h
//  Cooking Buddy Navigation
//
//  Created by Christine Ho on 5/10/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RecipeStorage.h"

@interface StepViewController : UIViewController{
    NSTimer *Timer;
}
@property (strong, nonatomic) RecipeStorage *recipe;
@property (weak, nonatomic) IBOutlet UIImage *food1;


- (void)changeButton;
- (IBAction)previous:(id)sender;
- (IBAction)next:(id)sender;
- (IBAction)startTimer:(id)sender;


@end