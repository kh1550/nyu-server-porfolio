//
//  StepViewController.m
//  Cooking Buddy Navigation
//
//  Created by Christine Ho on 5/10/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import "StepViewController.h"
#import "StepListViewController.h"
#import "RecipeStorage.h"

@interface StepViewController ()
@property (weak, nonatomic) IBOutlet UINavigationItem *recipeNavigation;
@property (weak, nonatomic) IBOutlet UIImageView *picture;
@property (weak, nonatomic) IBOutlet UILabel *stepLabel;
@property (weak, nonatomic) IBOutlet UILabel *instructions;
@property (weak, nonatomic) IBOutlet UIButton *previous;
@property (weak, nonatomic) IBOutlet UIButton *next;
@property (weak, nonatomic) IBOutlet UIButton *startTimer;
@property (weak, nonatomic) IBOutlet UILabel *timerDisplay;
@end

@implementation StepViewController
bool timer = false;
int stepNumber = 0;
int count = 0;
int timeAmount;
int stepTotal;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Navigation name changes in prepare for segue
    
    // Change step number label
    stepNumber = 1;
    self.stepLabel.text = [NSString stringWithFormat:@"Step %d", stepNumber];
    
    // Change instructions label
    self.instructions.text = [[[self.recipe returnArray] objectAtIndex:0] instruction];
    
    // RECEIVE IMAGE
    //UIImage *food = [UIImage imageNamed:@"steak.jpg"];
    [self.picture setImage:self.food1];
    
    // Change timer amount if timer exists
    timeAmount = [[[[self.recipe returnArray] objectAtIndex:0] timer] intValue];
    if (timeAmount > 0) {
        timer = true;
    } else {
        timer = false;
    }
    
    // Configure total number of steps
    stepTotal = (int)[[self.recipe returnArray] count];
    
    [self changeButton];
}

- (void) changeButton {
    // Timer
    if (timer == true) {
        _startTimer.alpha = 1;
        _startTimer.enabled = YES;
    } else {
        _startTimer.alpha = 0;
        _startTimer.enabled = NO;
    }
    
    // Previous
    if (stepNumber <= 1) {
        _previous.alpha = 0.4;
        _previous.enabled = NO;
    } else {
        _previous.alpha = 1;
        _previous.enabled = YES;
    }
    
    // Next
    if (stepNumber >= stepTotal) {
        _next.alpha = 0.4;
        _next.enabled = NO;
    } else {
        _next.alpha = 1;
        _next.enabled = YES;
    }
}

- (IBAction)previous:(id)sender {
    // End Timer
    [Timer invalidate];
    timer = false;
    count = 0;
    self.timerDisplay.text = @"";
    
    // Change Step Number
    stepNumber--;
    self.stepLabel.text = [NSString stringWithFormat: @"Step %d", stepNumber];
    
    // Change instruction for previous step
    self.instructions.text = [[[self.recipe returnArray] objectAtIndex:stepNumber-1] instruction];
    
    // Configure timer
    timeAmount = [[[[self.recipe returnArray] objectAtIndex:stepNumber-1] timer] intValue];
    if (timeAmount > 0) {
        timer = true;
    } else {
        timer = false;
    }
    
    // RECEIVE IMAGE
    //UIImage *food = [UIImage imageNamed:@"steak.jpg"];
    [self.picture setImage:self.food1];
    
    [self changeButton];
}

- (IBAction)next:(id)sender {
    // End Timer
    [Timer invalidate];
    timer = false;
    count = 0;
    self.timerDisplay.text = @"";
    
    // Change Step Number
    stepNumber++;
    self.stepLabel.text = [NSString stringWithFormat: @"Step %d", stepNumber];
    
    // Change instructions for next step
    self.instructions.text = [[[self.recipe returnArray] objectAtIndex:stepNumber-1] instruction];
    
    // Configure timer
    timeAmount = [[[[self.recipe returnArray] objectAtIndex:stepNumber-1] timer] intValue];
    if (timeAmount > 0) {
        timer = true;
    } else {
        timer = false;
    }
    
    
    // RECEIVE IMAGE
    //UIImage *food = [UIImage imageNamed:@"steak.jpg"];
    [self.picture setImage:self.food1];
    
    [self changeButton];
}

- (IBAction)startTimer:(id)sender {
    _startTimer.alpha = 0;
    _startTimer.enabled = NO;
    Timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerCount) userInfo:nil repeats:YES];
}

- (void)timerCount {
    count++;
    NSString *normalTime = [self convertToMinutes:count];
    self.timerDisplay.text = normalTime;
    
    if (count > timeAmount) {
        count = 0;
        self.timerDisplay.text = @"";
        [Timer invalidate];
        [self next:self];
        // Automatic next as described in presentation
    }
}

- (NSString *)convertToMinutes:(int)seconds {
    int min = floor(seconds/60);
    int secs = round(seconds - min * 60);
    NSString *secsStr = @"";
    if (secs < 10) {
        secsStr = [NSString stringWithFormat:@"0%d", secs];
    } else {
        secsStr = [NSString stringWithFormat:@"%d", secs];
    }
    NSString *result = [NSString stringWithFormat:@"%d:%@", min, secsStr];
    return result;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    StepListViewController *stepVC = segue.destinationViewController;
    stepVC.navigationItem.title = self.navigationItem.title;
    stepVC.recipe = [RecipeStorage new];
    stepVC.recipe = self.recipe;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:YES];
    
    if (self.isMovingFromParentViewController) {
        self.timerDisplay.text = @"";
        [Timer invalidate];
        count = 0;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
@end