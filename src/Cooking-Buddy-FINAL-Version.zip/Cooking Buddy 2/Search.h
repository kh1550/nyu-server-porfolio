//
//  Search.h
//  Cooking Buddy Navigation
//
//  Created by Michelle Chen on 5/15/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Search : UITableViewController <UISearchBarDelegate, UISearchDisplayDelegate>

@property (strong, nonatomic) NSArray *searchList;
@property (strong, nonatomic) NSMutableArray *resultsList;
@property IBOutlet UISearchBar *recipeSearchBar;

@end
