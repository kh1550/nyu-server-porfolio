//
//  Search.m
//  Cooking Buddy Navigation
//
//  Created by Michelle Chen on 5/15/15.
//  Copyright (c) 2015 Michelle Chen. All rights reserved.
//

#import "Search.h"

@interface Search ()

@end

@implementation Search
@synthesize searchList;
@synthesize resultsList;
@synthesize recipeSearchBar;

- (void)viewDidLoad {
    [super viewDidLoad];
    //Array where all searchable recipes are stored
    searchList = [NSArray arrayWithObjects:@"Grilled Steak", @"Garlic Chicken", @"Mushroom Pizza", @"Cheese & Beef Taco", @"Macaroni & Cheese", nil];
    
    //stores the filtered results of the search
    resultsList = [NSMutableArray arrayWithCapacity:[searchList count]];
    
    // Reload the table
    [[self tableView] reloadData];

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    
    //if search results
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return [resultsList count];
        
    } else {
        return [searchList count];
    }
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *SearchRecipeCell = @"SearchRecipeCell";
    
    //UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:SearchRecipeCell forIndexPath:indexPath];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:SearchRecipeCell];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SearchRecipeCell];
    }
    
    //populate list with full list or filtered search result list
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        cell.textLabel.text= self.resultsList[indexPath.row];
    } else {
        cell.textLabel.text = self.searchList[indexPath.row];
    }
    
    // Change cell font
    cell.textLabel.font = [UIFont fontWithName:@"Marker Felt" size:18];
    
    return cell;
}

#pragma mark Content Filtering

//filter the search bar text for matches.
- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    
    [self.resultsList removeAllObjects];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF contains[c] %@", searchText];
    NSArray *tempArray = [searchList filteredArrayUsingPredicate:predicate];
    
    //add the results to the array
    resultsList = [NSMutableArray arrayWithArray:tempArray];
}

//This function makes sure the tableView updates when the string entered in the search bar changes
-(BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{
    [self filterContentForSearchText:searchString scope:[[self.searchDisplayController.searchBar scopeButtonTitles] objectAtIndex:[self.searchDisplayController.searchBar selectedScopeButtonIndex]]];
    
    return YES;
}

@end
